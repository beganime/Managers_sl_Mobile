// app/(app)/catalog.tsx
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import {
    ActivityIndicator, FlatList, Keyboard,
    Platform, RefreshControl, StyleSheet, Text,
    TextInput, TouchableOpacity, UIManager, View
} from 'react-native';
import ScreenWrapper from '../../components/ScreenWrapper';
import { Layout } from '../../constants/theme';
import apiClient from '../../src/api/apiClient';
import { useTheme } from '../../src/context/ThemeContext';
import { getToken, saveToken } from '../../src/utils/storage';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
}

// Утилита для нечеткого поиска
const isMatch = (text: string, query: string) => {
    if (!query) return true;
    if (!text) return false;
    return text.toLowerCase().includes(query.toLowerCase());
};

const degreeMap: any = {
    'bachelor': 'Бакалавриат',
    'master': 'Магистратура',
    'specialist': 'Специалитет',
    'language': 'Языковые курсы'
};

type TabType = 'universities' | 'programs';

export default function CatalogScreen() {
    const router = useRouter();
    const { theme } = useTheme();
    const s = makeStyles(theme);

    const [universities, setUniversities] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [syncing, setSyncing] = useState(false);
    
    // Вкладки, Поиск и Пагинация (для плавной отрисовки UI)
    const [activeTab, setActiveTab] = useState<TabType>('universities');
    const [searchQuery, setSearchQuery] = useState('');
    const [debouncedQuery, setDebouncedQuery] = useState('');
    const [visibleCount, setVisibleCount] = useState(20);

    // Функция для выкачивания ВСЕХ страниц из API
    const fetchAllUniversities = async () => {
        let allData: any[] = [];
        let offset = 0;
        const limit = 100;
        let hasMore = true;

        while (hasMore) {
            const res = await apiClient.get(`catalog/universities/?limit=${limit}&offset=${offset}`);
            const data = res.data.results || res.data;
            
            if (Array.isArray(data)) {
                allData = [...allData, ...data];
            }
            
            // Если есть следующая страница — двигаем offset, иначе прерываем цикл
            if (res.data.next) {
                offset += limit;
            } else {
                hasMore = false;
            }
        }
        return allData;
    };

    const loadData = async () => {
        try {
            const cached = await getToken('cache_universities');
            if (cached) {
                setUniversities(JSON.parse(cached));
                setLoading(false); // Показываем кэш мгновенно
            }
            
            // Фоново догружаем свежие и ВСЕ данные
            const allData = await fetchAllUniversities();
            setUniversities(allData);
            await saveToken('cache_universities', JSON.stringify(allData));
        } catch (error) {
            console.log("Офлайн режим для каталога");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { loadData(); }, []);

    // Дебаунс поиска и сброс пагинации
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedQuery(searchQuery);
            setVisibleCount(20); // Сброс при новом поиске
        }, 300);
        return () => clearTimeout(handler);
    }, [searchQuery]);

    // Сброс пагинации при смене вкладки
    useEffect(() => {
        setVisibleCount(20);
    }, [activeTab]);

    const forceSyncData = async () => {
        setSyncing(true);
        try {
            const allData = await fetchAllUniversities();
            setUniversities(allData);
            await saveToken('cache_universities', JSON.stringify(allData));
        } catch (error) {
            // Офлайн
        } finally {
            setSyncing(false);
        }
    };

    // Извлекаем все программы в плоский массив
    const allPrograms = useMemo(() => {
        let display: any[] = [];
        universities.forEach(uni => {
            if (uni.programs && uni.programs.length > 0) {
                uni.programs.forEach((prog: any) => {
                    display.push({ ...prog, uni: uni });
                });
            }
        });
        return display;
    }, [universities]);

    // Фильтрация списков на основе поиска
    const filteredUniversities = useMemo(() => {
        if (!debouncedQuery) return universities;
        return universities.filter(u => isMatch(u.name, debouncedQuery) || isMatch(u.city, debouncedQuery));
    }, [universities, debouncedQuery]);

    const filteredPrograms = useMemo(() => {
        if (!debouncedQuery) return allPrograms;
        return allPrograms.filter(p => isMatch(p.name, debouncedQuery) || isMatch(p.uni.name, debouncedQuery));
    }, [allPrograms, debouncedQuery]);

    const loadMore = () => setVisibleCount(prev => prev + 20);

    const renderUniversityCard = ({ item: uni }: { item: any }) => (
        <TouchableOpacity 
            style={s.card} 
            activeOpacity={0.7}
            onPress={() => router.push(`/university/${uni.id}` as any)}
        >
            <View style={s.cardHeader}>
                <View style={[s.iconBox, { backgroundColor: theme.primary + '15' }]}>
                    <Ionicons name="school" size={24} color={theme.primary} />
                </View>
                <View style={s.cardTitleBox}>
                    <Text style={s.cardTitle}>{uni.name}</Text>
                    <Text style={s.cardSubtitle}>
                        <Ionicons name="location-outline" size={12} color={theme.textSub} /> {uni.city}, {uni.country}
                    </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={theme.border} />
            </View>
            <View style={s.cardFooter}>
                <Text style={s.footerText}>Программ доступно: <Text style={{fontWeight: '800', color: theme.text}}>{uni.programs?.length || 0}</Text></Text>
            </View>
        </TouchableOpacity>
    );

    const renderProgramCard = ({ item: prog }: { item: any }) => {
        // Динамическое определение валюты
        const currency = prog.currency?.code || prog.uni?.local_currency?.code || '';

        return (
            <View style={s.card}>
                <Text style={s.cardTitle}>{prog.name}</Text>
                
                <View style={s.tagsRow}>
                    <View style={[s.tag, { backgroundColor: theme.primary + '15' }]}>
                        <Text style={[s.tagText, { color: theme.primary }]}>{degreeMap[prog.degree] || prog.degree}</Text>
                    </View>
                    <View style={s.tag}>
                        <Ionicons name="time-outline" size={14} color={theme.textSub} style={{marginRight: 4}} />
                        <Text style={s.tagText}>{prog.duration}</Text>
                    </View>
                </View>

                <View style={s.uniInfoCompact}>
                    <Ionicons name="business" size={14} color={theme.textMuted} />
                    <Text style={s.uniInfoText} numberOfLines={1}>{prog.uni.name}</Text>
                </View>

                <View style={s.financeRow}>
                    <View>
                        <Text style={s.financeLabel}>Контракт</Text>
                        <Text style={s.financeValue}>
                            {parseFloat(prog.tuition_fee || 0).toLocaleString('ru-RU')} {currency}
                        </Text>
                    </View>
                    <View style={{ alignItems: 'flex-end' }}>
                        <Text style={s.financeLabel}>Наши услуги</Text>
                        <Text style={[s.financeValue, { color: theme.accent }]}>
                            {parseFloat(prog.service_fee || 0).toLocaleString('ru-RU')} {currency}
                        </Text>
                    </View>
                </View>
            </View>
        );
    };

    if (loading) return (
        <ScreenWrapper><View style={s.center}><ActivityIndicator size="large" color={theme.primary} /></View></ScreenWrapper>
    );

    const activeData = activeTab === 'universities' ? filteredUniversities : filteredPrograms;

    return (
        <ScreenWrapper>
            {/* Шапка с поиском */}
            <View style={s.header}>
                <Text style={s.pageTitle}>Каталог</Text>
                <View style={s.searchContainer}>
                    <Ionicons name="search" size={20} color={theme.textMuted} />
                    <TextInput 
                        style={s.searchInput} 
                        placeholder={activeTab === 'universities' ? "Поиск по ВУЗам..." : "Поиск по программам..."}
                        placeholderTextColor={theme.textMuted} 
                        value={searchQuery} 
                        onChangeText={setSearchQuery} 
                        returnKeyType="search"
                        onSubmitEditing={Keyboard.dismiss}
                    />
                    {searchQuery.length > 0 && (
                        <TouchableOpacity onPress={() => setSearchQuery('')}>
                            <Ionicons name="close-circle" size={20} color={theme.textMuted} />
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            {/* Вкладки (Tabs) */}
            <View style={s.tabsContainer}>
                <TouchableOpacity 
                    style={[s.tab, activeTab === 'universities' && s.activeTab]} 
                    onPress={() => setActiveTab('universities')}
                >
                    <Text style={[s.tabText, activeTab === 'universities' && s.activeTabText]}>
                        ВУЗы ({filteredUniversities.length})
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity 
                    style={[s.tab, activeTab === 'programs' && s.activeTab]} 
                    onPress={() => setActiveTab('programs')}
                >
                    <Text style={[s.tabText, activeTab === 'programs' && s.activeTabText]}>
                        Программы ({filteredPrograms.length})
                    </Text>
                </TouchableOpacity>
            </View>

            {/* Список с оптимизированной отрисовкой */}
            <FlatList
                data={activeData.slice(0, visibleCount)}
                keyExtractor={(item) => item.id.toString()}
                renderItem={activeTab === 'universities' ? renderUniversityCard : renderProgramCard}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={s.listContent}
                refreshControl={<RefreshControl refreshing={syncing} onRefresh={forceSyncData} tintColor={theme.primary} />}
                onEndReached={loadMore}
                onEndReachedThreshold={0.5}
                ListEmptyComponent={
                    <View style={s.emptyContainer}>
                        <Ionicons name="search-outline" size={48} color={theme.border} />
                        <Text style={s.emptyText}>По вашему запросу ничего не найдено</Text>
                    </View>
                }
            />
        </ScreenWrapper>
    );
}

function makeStyles(t: any) {
    return StyleSheet.create({
        center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
        header: { paddingHorizontal: 20, paddingTop: 10, paddingBottom: 15, backgroundColor: 'transparent' },
        pageTitle: { color: t.text, fontSize: 32, fontWeight: '900', letterSpacing: 0.5, marginBottom: 20 },
        
        searchContainer: { 
            flexDirection: 'row', alignItems: 'center', 
            backgroundColor: t.bgCard, borderRadius: Layout.radius.medium, 
            paddingHorizontal: 15, height: 50, 
            borderWidth: 1, borderColor: t.border,
            ...Layout.shadows.light 
        },
        searchInput: { flex: 1, color: t.text, marginLeft: 10, fontSize: 16, fontWeight: '500' },
        
        tabsContainer: { flexDirection: 'row', paddingHorizontal: 20, marginBottom: 15, gap: 10 },
        tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderRadius: Layout.radius.small, backgroundColor: t.bgChip, borderWidth: 1, borderColor: 'transparent' },
        activeTab: { backgroundColor: t.bgCard, borderColor: t.primary, ...Layout.shadows.light },
        tabText: { fontSize: 14, fontWeight: '700', color: t.textSub },
        activeTabText: { color: t.primary, fontWeight: '900' },

        listContent: { paddingHorizontal: 20, paddingBottom: 120 },
        
        card: { 
            backgroundColor: t.bgCard, borderRadius: Layout.radius.large, 
            padding: 20, marginBottom: 16, 
            borderWidth: 1, borderColor: t.border,
            ...Layout.shadows.light 
        },
        
        // Стили для ВУЗа
        cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
        iconBox: { width: 50, height: 50, borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
        cardTitleBox: { flex: 1 },
        cardTitle: { color: t.text, fontSize: 18, fontWeight: '800', marginBottom: 4 },
        cardSubtitle: { color: t.textSub, fontSize: 13, fontWeight: '600' },
        cardFooter: { borderTopWidth: 1, borderTopColor: t.border, paddingTop: 12 },
        footerText: { color: t.textSub, fontSize: 13 },

        // Стили для Программы
        tagsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
        tag: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, marginRight: 10, backgroundColor: t.bgChip },
        tagText: { color: t.textSub, fontSize: 12, fontWeight: '800', textTransform: 'uppercase' },
        uniInfoCompact: { flexDirection: 'row', alignItems: 'center', backgroundColor: t.bgSection, padding: 10, borderRadius: 10, marginBottom: 15 },
        uniInfoText: { color: t.textSub, fontSize: 13, fontWeight: '600', marginLeft: 8, flex: 1 },
        
        financeRow: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: t.border, paddingTop: 15 },
        financeLabel: { color: t.textMuted, fontSize: 11, fontWeight: '700', textTransform: 'uppercase', marginBottom: 4 },
        financeValue: { color: t.text, fontWeight: '900', fontSize: 18 },

        emptyContainer: { alignItems: 'center', justifyContent: 'center', marginTop: 80 },
        emptyText: { color: t.textMuted, textAlign: 'center', marginTop: 15, fontSize: 16, fontWeight: '600' },
    });
}