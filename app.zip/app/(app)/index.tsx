// app/(app)/index.tsx
import { ActivityIndicator, View } from 'react-native';
import AdminDashboard from '../../components/dashboard/AdminDashboard';
import ManagerDashboard from '../../components/dashboard/ManagerDashboard';
import ScreenWrapper from '../../components/ScreenWrapper';
import { useCurrentUser } from '../../hooks/useCurrentUser';

export default function DashboardScreen() {
    const { user, loading, reload } = useCurrentUser();

    if (loading || !user) {
        return (
            <ScreenWrapper>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                    <ActivityIndicator size="large" color="#007AFF" />
                </View>
            </ScreenWrapper>
        );
    }

    // Усиленная проверка на Админа. 
    // Теперь пустит, если ты superuser, staff или твоя роль указана как admin
    const isAdmin = user.is_superuser === true || user.is_staff === true || user.role === 'admin';

    if (isAdmin) {
        return <AdminDashboard user={user} onRefresh={reload} />;
    }

    return <ManagerDashboard user={user} onRefresh={reload} />;
}