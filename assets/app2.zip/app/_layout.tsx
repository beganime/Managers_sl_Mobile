import { Stack, usePathname, useRouter } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';

import { useCurrentUser } from '../hooks/useCurrentUser';
import { useTheme } from '../src/context/ThemeContext';
import { getToken } from '../src/utils/storage';

export default function RootLayout() {
  const router = useRouter();
  const pathname = usePathname();
  const { theme } = useTheme();
  const { reload } = useCurrentUser();

  const [booting, setBooting] = useState(true);
  const [hasToken, setHasToken] = useState(false);

  const isAuthRoute = useMemo(() => {
    return pathname === '/login' || pathname === '/';
  }, [pathname]);

  useEffect(() => {
    let mounted = true;

    const bootstrap = async () => {
      try {
        const token = await getToken('access_token');

        if (!mounted) return;

        setHasToken(Boolean(token));

        if (token) {
          try {
            await reload();
          } catch (e) {
            console.log('root layout reload failed', e);
          }
        }
      } finally {
        if (mounted) setBooting(false);
      }
    };

    bootstrap();

    return () => {
      mounted = false;
    };
  }, [reload]);

  useEffect(() => {
    if (booting) return;

    if (!hasToken && !isAuthRoute) {
      router.replace('/login');
      return;
    }

    if (hasToken && isAuthRoute) {
      router.replace('/(app)');
    }
  }, [booting, hasToken, isAuthRoute, router]);

  if (booting) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: theme.background,
        }}
      >
        <ActivityIndicator size="large" color={theme.blue} />
      </View>
    );
  }

  return <Stack screenOptions={{ headerShown: false }} />;
}