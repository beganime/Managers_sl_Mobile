import { Redirect } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';

import { useTheme } from '../src/context/ThemeContext';
import { getToken } from '../src/utils/storage';

export default function IndexScreen() {
  const { theme } = useTheme();
  const [ready, setReady] = useState(false);
  const [hasToken, setHasToken] = useState(false);

  useEffect(() => {
    let mounted = true;

    const check = async () => {
      try {
        const token = await getToken('access_token');
        if (!mounted) return;
        setHasToken(Boolean(token));
      } finally {
        if (mounted) setReady(true);
      }
    };

    check();

    return () => {
      mounted = false;
    };
  }, []);

  if (!ready) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: theme.background,
        }}
      >
        <ActivityIndicator size="large" color={theme.blue} />
      </View>
    );
  }

  return <Redirect href={hasToken ? '/(app)' : '/login'} />;
}